package com.metropolitan;

import javax.mail.MessagingException;

public class Main {
    public static void main(String[] args) {

        String excelFilePath = "putanja/do/studenti.xlsx";
        StudentExcelReader.readStudentsFromExcel(excelFilePath);


        try {
            EmailSender emailSender = EmailSender.getInstance();
            emailSender.sendEmail("primatelj@example.com", "Test", "Test poruka.");
            System.out.println("Mejl uspjesno poslat.");
        } catch (MessagingException e) {
            System.err.println("Greska pri slanju mejla: " + e.getMessage());
        }
    }
}

