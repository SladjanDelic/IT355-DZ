

import com.metropolitan.EmailSender;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class EmailSenderTest {

    @Test
    public void testSendEmail() {

        String recipientEmail = "primer@gmail.com";
        String subject = "Testna poruka";
        String body = "Ovo je testna poruka.";


        EmailSender emailSender = EmailSender.getInstance();


        assertDoesNotThrow(() -> {
            emailSender.sendEmail(recipientEmail, subject, body);
        });
    }
}
