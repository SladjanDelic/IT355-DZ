package com.metropolitan;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

@Service
public class OblikServis {
    private static final Log LOG = LogFactory.getLog(OblikServis.class);

    public void prikaziPodatke(double stranicaKvadrata, double poluprecnikKruga, double stranicaTrougla) {
        if (stranicaKvadrata <= 0 || poluprecnikKruga <= 0 || stranicaTrougla <= 0) {
            throw new IllegalArgumentException("Unos mora biti pozitivan broj.");
        }

        Kvadrat kvadrat = new Kvadrat(stranicaKvadrata);
        Krug krug = new Krug(poluprecnikKruga);
        jednakoStranicniTrougao trougao = new jednakoStranicniTrougao(stranicaTrougla);

        LOG.info("Podaci o kvadratu:");
        LOG.info("Obim: " + kvadrat.obim());
        LOG.info("Povrsina: " + kvadrat.povrsina());

        LOG.info("Podaci o krugu:");
        LOG.info("Obim: " + krug.obim());
        LOG.info("Povrsina: " + krug.povrsina());

        LOG.info("Podaci o jednakostranicnom trouglu:");
        LOG.info("Obim: " + trougao.obim());
        LOG.info("Povrsina: " + trougao.povrsina());
    }
}
