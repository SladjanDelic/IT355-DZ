package com.metropolitan;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        OblikServis oblikServis = context.getBean(OblikServis.class);
        Scanner scanner = new Scanner(System.in);

        try {
            double duzinaStraniceKvadrata;
            double poluprecnikKruga;
            double duzinaStraniceTrougla;

            System.out.println("Unesite duzinu stranice kvadrata:");
            duzinaStraniceKvadrata = scanner.nextDouble();
            if (duzinaStraniceKvadrata <= 0) {
                throw new IllegalArgumentException("Duzina stranice kvadrata mora biti pozitivan broj.");
            }

            System.out.println("Unesite poluprecnik kruga:");
            poluprecnikKruga = scanner.nextDouble();
            if (poluprecnikKruga <= 0) {
                throw new IllegalArgumentException("Poluprecnik kruga mora biti pozitivan broj.");
            }

            System.out.println("Unesite duzinu stranice jednakostranicnog trougla:");
            duzinaStraniceTrougla = scanner.nextDouble();
            if (duzinaStraniceTrougla <= 0) {
                throw new IllegalArgumentException("Duzina stranice trougla mora biti pozitivan broj.");
            }

            oblikServis.prikaziPodatke(duzinaStraniceKvadrata, poluprecnikKruga, duzinaStraniceTrougla);
        } catch (IllegalArgumentException ex) {
            System.out.println("Doslo je do greske: " + ex.getMessage());
        } finally {
            scanner.close();
        }
    }
}
