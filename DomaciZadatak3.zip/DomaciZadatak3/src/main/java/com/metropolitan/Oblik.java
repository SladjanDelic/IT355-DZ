package com.metropolitan;

public interface Oblik {

   double obim();
   double povrsina();

    };

