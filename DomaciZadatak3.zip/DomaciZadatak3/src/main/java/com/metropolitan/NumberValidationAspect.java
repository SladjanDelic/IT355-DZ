package com.metropolitan;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class NumberValidationAspect {

    private static final Log LOG = LogFactory.getLog(NumberValidationAspect.class);

    @Before("execution(* com.metropolitan.Kvadrat.*(..)) && args(value,..)")
    public void validateInputForKvadrat(JoinPoint joinPoint, double value) {
        if (value <= 0) {
            String methodName = joinPoint.getSignature().getName();
            LOG.error("Detected negative or zero value for method: " + methodName);
            System.out.println("Upozorenje: Unijeli ste negativan ili nula za duzinu stranice.");
        }
    }

    @AfterReturning("execution(* com.metropolitan..*(..))")
    public void afterReturningAdvice(JoinPoint joinPoint) {
        LOG.info("After returning advice: " + joinPoint.getSignature().getName());
        System.out.println("Greska: Duzina stranice ne moze biti negativan broj ili nula.");
    }

    @AfterThrowing(pointcut = "execution(* com.metropolitan..*(..))", throwing = "ex")
    public void afterThrowingAdvice(JoinPoint joinPoint, Exception ex) {
        LOG.error("After throwing advice: " + joinPoint.getSignature().getName() + ", Exception: " + ex.getMessage());
    }

    @Around("execution(* com.metropolitan..*(..))")
    public Object aroundAdvice(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        LOG.info("Around advice (before): " + proceedingJoinPoint.getSignature().getName());
        try {
            Object result = proceedingJoinPoint.proceed();
            LOG.info("Around advice (after returning): " + proceedingJoinPoint.getSignature().getName());
            return result;
        } catch (Throwable throwable) {
            LOG.error("Around advice (after throwing): " + proceedingJoinPoint.getSignature().getName() + ", Exception: " + throwable.getMessage());
            throw throwable;
        } finally {
            LOG.info("Around advice (after): " + proceedingJoinPoint.getSignature().getName());
        }
    }
}
