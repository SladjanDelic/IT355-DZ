package com.metropolitan;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ExceptionHandlerAspect {
    private static final Log LOG = LogFactory.getLog(ExceptionHandlerAspect.class);

    @Before("execution(* com.metropolitan..*(..))")
    public void beforeAdvice(JoinPoint joinPoint) {
        LOG.info("Before advice: " + joinPoint.getSignature().getName());
    }

    @After("execution(* com.metropolitan..*(..))")
    public void afterAdvice(JoinPoint joinPoint) {
        LOG.info("After advice: " + joinPoint.getSignature().getName());
    }

    @AfterReturning("execution(* com.metropolitan..*(..))")
    public void afterReturningAdvice(JoinPoint joinPoint) {
        LOG.info("After returning advice: " + joinPoint.getSignature().getName());
    }

    @AfterThrowing(pointcut = "execution(* com.metropolitan..*(..))", throwing = "ex")
    public void afterThrowingAdvice(JoinPoint joinPoint, Exception ex) {
        LOG.error("After throwing advice: " + joinPoint.getSignature().getName() + ", Exception: " + ex.getMessage());
    }

    @Around("execution(* com.metropolitan..*(..))")
    public Object aroundAdvice(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        LOG.info("Around advice (before): " + proceedingJoinPoint.getSignature().getName());
        try {
            Object result = proceedingJoinPoint.proceed();
            LOG.info("Around advice (after returning): " + proceedingJoinPoint.getSignature().getName());
            return result;
        } catch (Throwable throwable) {
            LOG.error("Around advice (after throwing): " + proceedingJoinPoint.getSignature().getName() + ", Exception: " + throwable.getMessage());
            throw throwable;
        } finally {
            LOG.info("Around advice (after): " + proceedingJoinPoint.getSignature().getName());
        }
    }
}
