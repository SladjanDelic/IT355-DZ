package org.example;

import org.apache.poi.ss.usermodel.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class StudentExcelReader {




    public static void readStudentsFromExcel(String filePath) {
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = WorkbookFactory.create(fis)) {

            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {

                if (row.getRowNum() == 0) {
                    continue;
                }

                Cell firstNameCell = row.getCell(0);
                Cell lastNameCell = row.getCell(1);
                Cell indexNumberCell = row.getCell(2);

                if (firstNameCell != null && lastNameCell != null && indexNumberCell != null) {
                    String firstName = firstNameCell.getStringCellValue();
                    String lastName = lastNameCell.getStringCellValue();
                    String indexNumber = indexNumberCell.getStringCellValue();

                    System.out.println("Student: " + firstName + " " + lastName + ", Index number: " + indexNumber);
                }
            }

        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + filePath);
        } catch (IOException e) {
            System.err.println("Error reading Excel file: " + e.getMessage());
        }
    }
}
