package com.metropolitan;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        OblikServis oblikServis = context.getBean(OblikServis.class);
        Scanner scanner = new Scanner(System.in);

        System.out.println("Unesite duzinu stranice kvadrata:");
        double duzinaStraniceKvadrata = scanner.nextDouble();
        Oblik kvadrat = new Kvadrat(duzinaStraniceKvadrata);

        System.out.println("Unesite poluprecnik kruga:");
        double poluprecnikKruga = scanner.nextDouble();
        Oblik krug = new Krug(poluprecnikKruga);

        System.out.println("Unesite duzinu stranice jednakostranicnog trougla:");
        double duzinaStraniceTrougla = scanner.nextDouble();
        Oblik trougao = new jednakoStranicniTrougao(duzinaStraniceTrougla);

        oblikServis.prikaziPodatke(kvadrat);
        oblikServis.prikaziPodatke(krug);
        oblikServis.prikaziPodatke(trougao);

        scanner.close();
    }
}