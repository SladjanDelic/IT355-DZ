package com.metropolitan;

import org.springframework.context.annotation.Bean;

public class AppConfig {

    @Bean
    public OblikServis oblikServis(){
        return new OblikServis();
    }
}
