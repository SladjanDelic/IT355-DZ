package com.metropolitan;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class OblikServis{
    public static final Log LOG = LogFactory.getLog(OblikServis.class);

    public void prikaziPodatke(Oblik oblik) {
        if (oblik instanceof Kvadrat) {
            LOG.info("Podaci o kvadratu:");
        } else if (oblik instanceof Krug) {
            LOG.info("Podaci o krugu:");
        } else if (oblik instanceof jednakoStranicniTrougao) {
            LOG.info("Podaci o jednakostranicnom trouglu:");
        } else {
            LOG.warn("Nepoznat oblik.");
            return;
        }
        LOG.info("Obim: " + oblik.obim());
        LOG.info("Povrsina: " + oblik.povrsina());
    }
}


